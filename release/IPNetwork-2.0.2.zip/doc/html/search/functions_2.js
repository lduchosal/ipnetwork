var searchData=
[
  ['isianareserved',['IsIANAReserved',['../class_system_1_1_net_1_1_i_p_network.html#adbbc960d6bf2e253c082d5fb35d210ef',1,'System.Net.IPNetwork.IsIANAReserved(IPAddress ipaddress)'],['../class_system_1_1_net_1_1_i_p_network.html#a11d560c4fe4e0d8b8626ea52d661f203',1,'System.Net.IPNetwork.IsIANAReserved(IPNetwork ipnetwork)']]]
];
