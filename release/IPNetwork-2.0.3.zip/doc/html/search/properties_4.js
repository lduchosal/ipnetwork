var searchData=
[
  ['iana_5fablk_5freserved1',['IANA_ABLK_RESERVED1',['../class_system_1_1_net_1_1_i_p_network.html#a2f62e1efc671d413d3ddc3bfbba53271',1,'System::Net::IPNetwork']]],
  ['iana_5fbblk_5freserved1',['IANA_BBLK_RESERVED1',['../class_system_1_1_net_1_1_i_p_network.html#a7b6e4974159ed7547fc9ae0fe75dc8cb',1,'System::Net::IPNetwork']]],
  ['iana_5fcblk_5freserved1',['IANA_CBLK_RESERVED1',['../class_system_1_1_net_1_1_i_p_network.html#afc4a129739c9c740b60688e11afbed2f',1,'System::Net::IPNetwork']]]
];
