var searchData=
[
  ['subnet',['Subnet',['../class_system_1_1_net_1_1_i_p_network.html#ae1cb7efcb7eebeb4714d51d163913450',1,'System::Net::IPNetwork']]],
  ['supernet',['Supernet',['../class_system_1_1_net_1_1_i_p_network.html#a79d13eb0a9599822f88f81ac8a511450',1,'System.Net.IPNetwork.Supernet(IPNetwork network1, IPNetwork network2)'],['../class_system_1_1_net_1_1_i_p_network.html#aef3bffcc963b75153abc4e5d836269db',1,'System.Net.IPNetwork.Supernet(IPNetwork[] ipnetworks)']]]
];
