var searchData=
[
  ['isianareserved',['IsIANAReserved',['../class_system_1_1_net_1_1_i_p_network.html#adbbc960d6bf2e253c082d5fb35d210ef',1,'System.Net.IPNetwork.IsIANAReserved(IPAddress ipaddress)'],['../class_system_1_1_net_1_1_i_p_network.html#a5a4f2cbe05b789333366ef309049e8c7',1,'System.Net.IPNetwork.IsIANAReserved()']]]
];
