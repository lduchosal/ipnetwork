var searchData=
[
  ['iana_5fablk_5freserved1',['IANA_ABLK_RESERVED1',['../class_system_1_1_net_1_1_i_p_network.html#a2f62e1efc671d413d3ddc3bfbba53271',1,'System::Net::IPNetwork']]],
  ['iana_5fbblk_5freserved1',['IANA_BBLK_RESERVED1',['../class_system_1_1_net_1_1_i_p_network.html#a7b6e4974159ed7547fc9ae0fe75dc8cb',1,'System::Net::IPNetwork']]],
  ['iana_5fcblk_5freserved1',['IANA_CBLK_RESERVED1',['../class_system_1_1_net_1_1_i_p_network.html#afc4a129739c9c740b60688e11afbed2f',1,'System::Net::IPNetwork']]],
  ['ipaddresscollection',['IPAddressCollection',['../class_system_1_1_net_1_1_i_p_address_collection.html',1,'System::Net']]],
  ['ipnetwork',['IPNetwork',['../class_system_1_1_net_1_1_i_p_network.html',1,'System::Net']]],
  ['ipnetworkcollection',['IPNetworkCollection',['../class_system_1_1_net_1_1_i_p_network_collection.html',1,'System::Net']]],
  ['isianareserved',['IsIANAReserved',['../class_system_1_1_net_1_1_i_p_network.html#adbbc960d6bf2e253c082d5fb35d210ef',1,'System.Net.IPNetwork.IsIANAReserved(IPAddress ipaddress)'],['../class_system_1_1_net_1_1_i_p_network.html#a5a4f2cbe05b789333366ef309049e8c7',1,'System.Net.IPNetwork.IsIANAReserved()']]]
];
